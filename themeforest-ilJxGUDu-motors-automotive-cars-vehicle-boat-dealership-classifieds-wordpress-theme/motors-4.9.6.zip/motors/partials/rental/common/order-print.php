<div class="stm_order_print">
    <a href="javascript:window.print()" class="button">
        <?php esc_html_e('Print', 'motors'); ?>
        <i class="fa fa-print"></i>
    </a>
</div>