<?php if(function_exists('stm_get_shares')) {
	//
	//stm_get_shares();
	var_dump("SHARES SHARES");
}