<?php
/**
 * Plugin Name: STM Import Makes & Models
 * Description: Additional functionality for importing Makes & Models for Motors theme
 * Author: StylemixThemes
 * Author URI: https://stylemixthemes.com/
 * Version: 2.0
 */

add_action( 'admin_menu', 'stmmi_admin_menu' );
function stmmi_admin_menu() {
	$stmi = Stmi::i();
	$hook = add_management_page( __( 'Import Makes & Models', 'stmi' ), __( 'Import Makes & Models', 'stmi' ), 'manage_options', 'stmi', array( $stmi, 'page' ) );
	add_action( 'load-' . $hook, array( $stmi, 'load' ) );
}


class Stmi
{

	public static function i() {
		static $i;

		if ( ! isset( $i ) ) {
			$i = new self();
		}

		return $i;
	}

	public function load() {
		if ( $_SERVER['REQUEST_METHOD'] != 'POST' ) {
			return;
		}

		// Let server to force output
		header( 'Content-type: text/html; charset=utf-8' );

		echo '<pre>';

		$this->log( 'Import started', 'info' );
		
		$make_tax = @$_POST['make_tax'];
		$model_tax = @$_POST['model_tax'];
		$make_col_name = @$_POST['make_col'];
		$model_col_name = @$_POST['model_col'];
		$separator = @$_POST['separator'];

		if ( ! taxonomy_exists( $make_tax ) || ! taxonomy_exists( $model_tax ) ) {
			echo 'Selected taxonomies does not exist.';
			exit;
		}

		if ( ! $make_col_name || ! $model_col_name ) {
			echo 'Please, provide both makes and models column names.';
			exit;
		}

		update_option( 'stmi_make_tax', $make_tax, false );
		update_option( 'stmi_model_tax', $model_tax, false );
		update_option( 'separator', $separator, false );
		update_option( 'stmi_make_col', $make_col_name, false );
		update_option( 'stmi_model_col', $model_col_name, false );

		if ( empty( $_FILES['file'] ) ) {
			echo 'Please, upload as CSV file.';
			exit;
		}

		if ( $_FILES['file']['error'] != UPLOAD_ERR_OK ) {
			echo 'CSV file upload error. Please try again.';
			exit;
		}

		$f = fopen( $_FILES['file']['tmp_name'], 'r' );

		if ( ! $f ) {
			echo 'Error opening file. Please try again.';
			exit;
		}

		$all_makes = get_terms( array( 'taxonomy' => $make_tax, 'hide_empty' => false, 'update_term_meta_cache' => false ) );
		$all_makes = array_combine( array_map( 'strtolower', wp_list_pluck( $all_makes, 'name' ) ), $all_makes );
		$this->log( 'Found makes: ' . count( $all_makes ) );

		$all_models = get_terms( array( 'taxonomy' => $model_tax, 'hide_empty' => false, 'update_term_meta_cache' => false, ) );
		$all_models = array_combine( array_map( 'strtolower', wp_list_pluck( $all_models, 'name' ) ), $all_models );
		$this->log( 'Found models: ' . count( $all_models ) );

		// header
		$_header = fgetcsv( $f, 99999, $separator );
		$_make_col = array_search( $make_col_name, $_header );
		$_model_col = array_search( $model_col_name, $_header );

		$errors_count = 0;
		$_last_make = null;

		while ( $_row = fgetcsv( $f, 99999, $separator ) ) {
			$_row = array_filter( array_map( 'trim', $_row ) );
			
			if ( empty( $_row ) || empty( $_row[ $_make_col ] ) || empty( $_row[ $_model_col ] ) ) {
				continue;
			}

			if ( $errors_count > 10 ) {
				$this->log( 'Too many failures.', 'error' );
				break;
			}

			$_make_name = sanitize_text_field( $_row[ $_make_col ] );
			if ( empty( $_make_name ) ) {
				continue;
			}

			if ( ! array_key_exists( strtolower( $_make_name ), $all_makes ) ) {
				// create make term
				$make_term = (object) wp_insert_term( $_make_name, $make_tax );
				if ( is_wp_error( $make_term ) ) {
					$errors_count ++;
					$this->log( 'Failed to create term: ' . $_make_name . '. ' . $make_term->get_error_message(), 'error' );
					continue;
				} else {
					$make_term = get_term( $make_term->term_id, $make_tax );
					$all_makes[ strtolower( $_make_name ) ] = $make_term;
					$operation = '<u>created</u>';
				}
			} else {
				$operation = '<u>exists</u>';
				$make_term = $all_makes[ strtolower( $_make_name ) ];
			}

			if ( $_last_make != $_make_name ) {
				$this->log( 'Make: <b>' . $_make_name . '</b> [' . $make_term->slug . '] - ' . $operation . ' id:' . $make_term->term_id );
				$_last_make = $_make_name;
			}

			// process model
			$_model_name = sanitize_text_field( $_row[ $_model_col ] );
			if ( empty( $_model_name ) ) {
				continue;
			}

			if ( ! array_key_exists( strtolower( $_model_name ), $all_models ) ) {
				$this->log( '- ' . strtolower( $_model_name ) . ' not found, creating' );
				// create model term
				$model_term = (object) wp_insert_term( $_model_name, $model_tax );
				if ( is_wp_error( $model_term ) ) {
					$errors_count ++;
					$this->log( 'Failed to create term: ' . $_model_name . '. ' . $model_term->get_error_message(), 'error' );
					continue;
				} else {
					$model_term = get_term( $model_term->term_id, $model_tax );
					$all_models[ strtolower( $_model_name ) ] = $model_term;
					$operation = '<u>created</u>';
				}
			} else {
				$operation = '<u>exists</u>';
				$model_term = $all_models[ strtolower( $_model_name ) ];
			}

			// Set make as parent of this model
			update_term_meta($model_term->term_id, 'stm_parent', $make_term->slug);

			$this->log( '- model: <b>' . $_model_name . '</b> [' . $model_term->slug . '] - ' . $operation . ' id:' . $model_term->term_id  );
		}

		fclose( $f );

		if ( ! $errors_count ) {
			$this->log( 'Import has been finished successfully', 'success' );
		}
		exit;
	}


	public function page() {
		$tax_make = get_option( 'stmi_make_tax', 'make' );
		$tax_model = get_option( 'stmi_model_tax', 'model' );
		$separator = esc_attr( get_option( 'separator', ',' ) );
		$make_col = esc_attr( get_option( 'stmi_make_col', 'Make' ) );
		$model_col = esc_attr( get_option( 'stmi_model_col', 'Model' ) );

		$taxs = get_option( 'stm_vehicle_listing_options' );
		$options = array(
			'make' => '<option></option>',
			'model' => '<option></option>',
		);

		foreach ( $taxs as $option ) {
			$options['make'] .= '<option value="' . $option['slug'] . '"' . selected( $tax_make, $option['slug'], false ) . '>' . $option['plural_name'] . '</option>';
			$options['model'] .= '<option value="' . $option['slug'] . '"' . selected( $tax_model, $option['slug'], false ) . '>' . $option['plural_name'] . '</option>';
		}

		echo <<<HTML
<div class="wrap">
	<h2>Import Makes & Models</h2>

	<h4>Plugin creates relationship automatically! You med just to select correct taxonomies and enter Column names from your CSV file.</h4>
	
	<form method="POST" enctype="multipart/form-data" target="process">
		<table class="form-table">
			<tbody>
			<tr valign="top">
				<th scope="row">
					<label for="taxonomy-makes">Choose your Makes taxonomy</label>
				</th>
				<td>
					<select id="taxonomy-makes" name="make_tax">{$options['make']}</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="taxonomy-models">Choose your Models taxonomy</label>
				</th>
				<td>
					<select id="taxonomy-models" name="model_tax">{$options['model']}</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="column-makes">CSV Separator symbol (,)</label>
				</th>
				<td>
					<input type="text" id="column-makes" name="separator" value="$separator">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="column-makes">Makes column name</label>
				</th>
				<td>
					<input type="text" id="column-makes" name="make_col" value="$make_col">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="column-models">Models column name</label>
				</th>
				<td>
					<input type="text" id="column-models" name="model_col" value="$model_col">
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<label for="file">CSV file to import</label>
				</th>
				<td>
					<input type="file" id="file" name="file" />
				</td>
			</tr>
			</tbody>
		</table>
		<p>
			<input type="submit" value="Start import" class="button-primary">
		</p>
	</form>
	<iframe name="process" frameborder="0" width="100%" height="400px"></iframe>
</div>
HTML;

	}

	protected function log( $message, $type = '' ) {
		$colors = array(
			'' => '#444',
			'info' => '#00a',
			'success' => '#0a0',
			'error' => '#a00',
		);

		$color = $colors[ $type ];

		echo "<div style=\"color: $color\">$message</div>";
		while ( ob_get_level() ) {
			ob_end_flush();
		}
		flush();
	}
}
