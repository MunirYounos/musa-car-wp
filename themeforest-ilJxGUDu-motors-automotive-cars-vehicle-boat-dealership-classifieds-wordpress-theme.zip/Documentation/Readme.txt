Dear Buyers,

Thanks for purchase of our Motors Theme!

Online Documentation is available here: http://stylemixthemes.com/manuals/motors/

For support questions please go to http://stylemixthemes.com/support/

Thank you for choosing us!

StylemixThemes